
EE.main.targetConfiguration = {
	'PASSWORD_STRENGTH_METER': $.proxy(EE.main.createPasswordStrength, EE.main)
};
